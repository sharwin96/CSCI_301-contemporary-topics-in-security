import hashlib,binascii,json
from Crypto.PublicKey import DSA
from Crypto.Signature import DSS
from Crypto.Hash import SHA256

#create the public key ( Q1 )

key = DSA.generate(2048)

tup = [key.y, key.g, key.p, key.q]

g = hex(key.g)  # g parameter
#print("Hex G : " + g)
#print("Hex G : " + int(key.g,16))
#print()

p = hex(key.p)
#hex_p = hashlib.sha256(p.encode()).hexdigest() #p parameter
# print("Hex P : " + p)
# print()
 
q = hex(key.q)
#hex_q = hashlib.sha256(q.encode()).hexdigest() # q parameter
# print("Hex Q : " + q)
#print("Hex Q : " + int(key.q,16))

# print()

#print("before hex public key : " + str(key.y) )
publickey = hex(key.y)
#hex_publicKey = hashlib.sha256(publickey.encode()).hexdigest() # public key
#print ("public key : " + publickey)
#print ()

prv = open("SigningKey.txt","w")
prv.write(hex(key.x))
prv.close()

DSAParam = [g,p,q]

tx = json.dumps({'DSA Param': DSAParam, 'pubkey':publickey},sort_keys=True, indent=4, separators=(',', ': '))
#print(tx)


#Compute the signature 
message = b"CSCI301 Contemporary topic in security"
hash_obj = SHA256.new(message)
signer = DSS.new(key, 'fips-186-3')
signature = signer.sign(hash_obj)
#print("signature : " + str(signature))

sig = binascii.hexlify(signature) #hexadecimal signature
#print ("hexlify sig : {}".format(sig))
#print ("hexlify sig(type) : {}".format(type(sig)))

hex_sig = int(sig,16)
#print("int sig : {}".format(hex_sig) )

tx = json.dumps({'DSA Param': DSAParam, 'pubkey':publickey,'Sig' : hex(hex_sig)},sort_keys=False, indent=4, separators=(',', ': '))
#print(tx)

#q3 - hash the public key 
#str_publicKey = str(publickey)
str_publicKey = str(key.y)
#print("public key(string) : " + str_publicKey)
hash_publicKey = hashlib.sha256(str_publicKey.encode()).hexdigest()
#print("hashed public key : {}".format(hash_publicKey))
length_pk = len(hash_publicKey)
#print(length_pk)
lsb = hash_publicKey[24:length_pk]
#print(len(lsb))
#print(lsb)

int_lsb = int(lsb,16) 

tx = json.dumps({'DSA Param': DSAParam, 'pubkey':publickey,'Sig' : hex(hex_sig),"pubKeyHash": hex(int_lsb)},sort_keys=False, indent=4, separators=(',', ': '))
#print(tx)

#write to a .json file
file = open("Assignment2.json","w+")
file.write(tx)
file.close()
print("Assignment2.json write .......")
