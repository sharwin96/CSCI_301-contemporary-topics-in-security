import hashlib,binascii,json,os
from Crypto.PublicKey import DSA
from Crypto.Signature import DSS
from Crypto.Hash import SHA256

#function to duplicate something
def OP_DUP(data):
    duplicated = data
    return duplicated

#function to computes the 160 least significant bits of SHA256 hash value of the last value in the stack
def OP_HASH160(stack):
    top = stack.peek()
    unhex_top = int(top,0)
    #print("unhexed pubkey --> {}".format(unhex_top) )
    
    str_publicKey = str(unhex_top)
    #print("public key(string) : " + str_publicKey)
   
    hash_publicKey = hashlib.sha256(str_publicKey.encode()).hexdigest()
    #print("hashed public key : {}".format(hash_publicKey))
    length_pk = len(hash_publicKey)
    #print(length_pk)
    lsb = hash_publicKey[24:length_pk]
    #print(len(lsb))
    #print(lsb)

    int_lsb = int(lsb,16) 
    pubHashA = hex(int_lsb)
    #print("pubHashA --> {}".format(pubHashA) )
    
    stack.pop()
    stack.push(pubHashA)
    
    
def OP_EQUALVERIFY(stack):
    thisIsPubKeyHash = stack.peek()
    #print(thisIsPubKeyHash)
    
    thisIsPubKey = stack.peekSecond()
    #print(thisIsPubKey)
    
    if(thisIsPubKey == thisIsPubKeyHash):
        stack.pop()
        stack.pop()
        
        
def OP_CHECKSIG(stack,dsaParam):
    pubkey = stack.peek()
    pubkey = int(pubkey,0)
    #print("pubkey(hex) -->> " + str(pubkey))
    
    sig = stack.peekSecond()
    #print("sig -->> " + str(sig))
    #print("bin -->> {}".format(str(sig).encode()))

    signature =bytes.fromhex(sig[2:])
    #print("signature -->> {}".format(signature))
    
    
    #g value 
    dsa_g = dsaParam[0]
    dsa_g = int(dsa_g,0) #  g value unhex
    #print("g : {}".format(dsa_g) )
    
    #p value
    dsa_p = dsaParam[1]
    dsa_p = int(dsa_p,0) # p value unhex
    #print("p : {}".format(dsa_p) )
    
    #q value
    dsa_q = dsaParam[2] 
    dsa_q = int(dsa_q,0) # q value unhex
    #print("q : {}".format(dsa_q) )
    
    message = b"CSCI301 Contemporary topic in security"
    tup = [pubkey,dsa_g,dsa_p,dsa_q]
    
    pub_key = DSA.construct(tup)

    hash_obj = SHA256.new(message)
    #print(hash_obj)
    
    verifier = DSS.new(pub_key, 'fips-186-3')
    try:
        verifier.verify(hash_obj, signature)
        print("The message is authentic.")
        
        stack.pop()
        stack.pop()
        print("Empty stack...")
        
    except ValueError:
        print("The message is not authentic.")
    





#implementation of the stack
class Stack:
     def __init__(self):
         self.items = []

     def isEmpty(self):
         return self.items == []

     def push(self, item):
         self.items.append(item)

     def pop(self):
         return self.items.pop()

     def peek(self):
         return self.items[len(self.items)-1]

     def size(self):
         return len(self.items)
     
     def displayStack(self):
         return self.items
     
     def peekSecond(self):
         return self.items[len(self.items)-2]



def main():
    stack = Stack()

    #read the values in Assignment2.json
    file = open("Assignment2.json","r")
    filedata = file.read()
    #print(filedata)
    file.close()

    jsonBlock = json.loads(filedata)

    pubKey = jsonBlock["pubkey"]
    #print(pubKey)

    #print()

    sig = jsonBlock["Sig"]
    #print(sig)

    #add <sig> <pubKey> to the stack
    stack.push(sig)
    stack.push(pubKey)

    # print("\n{}".format(stack.displayStack()) )
    
    #Top stack item will be duplicated
    topper = stack.peek() # return the data that is currently at the top
    duplicate_topper = OP_DUP(topper) # make a duplicate of the data at the end
    stack.push(duplicate_topper) # add the duplicate data to the top
    
    # print("\n{}".format(stack.displayStack()) )
    
    #hash the data at the top of the stack
    OP_HASH160(stack)
    #print("\n{}".format(stack.displayStack()) )
    
    #add pubKeyHash to the stack
    pubkeyHash = jsonBlock["pubKeyHash"]
    # print("\n{}".format(pubkeyHash))
    stack.push(pubkeyHash)
    #print("\n{}".format(stack.displayStack()) )
    
    #check if the top 2 values are the same
    OP_EQUALVERIFY(stack)
    #print("\nStack after verification ==>> {}".format(stack.displayStack()) )
    
    dsaParam = jsonBlock["DSA Param"]
    OP_CHECKSIG(stack,dsaParam)
    
    #print("\n{}".format(stack.displayStack()) )
    
    
if __name__ == "__main__":
    main()
